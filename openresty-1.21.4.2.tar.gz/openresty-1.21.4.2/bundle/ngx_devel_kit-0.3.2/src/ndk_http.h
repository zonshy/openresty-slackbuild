
ngx_uint_t  ndk_http_count_phase_handlers       (ngx_http_core_main_conf_t *cmcf);
ngx_uint_t  ndk_http_parse_request_method       (ngx_str_t *m);
